<?
$MESS["AWZ_YDELIVERY_YDAPI_RESPERROR"] = "Пустой ответ внешнего апи";
?>