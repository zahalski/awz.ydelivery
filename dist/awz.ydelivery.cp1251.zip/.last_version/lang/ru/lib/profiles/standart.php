<?
$MESS["AWZ_YDELIVERY_PROFILE_STANDART_NAME"] = "AWZ: Яндекс Доставка курьером";
$MESS["AWZ_YDELIVERY_PROFILE_STANDART_DESC"] = "Обработчик доставки: Яндекс Доставка курьером";
$MESS["AWZ_YDELIVERY_PROFILE_STANDART_SETT_INTG"] = "Интеграция";
$MESS["AWZ_YDELIVERY_PROFILE_STANDART_SETT_INTG_DESC"] = "Основные настройки интеграции";
$MESS["AWZ_YDELIVERY_PROFILE_STANDART_SETT_TEST_MODE"] = "Тестовый режим";
$MESS["AWZ_YDELIVERY_PROFILE_STANDART_SETT_TOKEN"] = "Ключ API";
$MESS["AWZ_YDELIVERY_PROFILE_STANDART_SETT_TOKEN_TEST"] = "Ключ API Тестовый";
$MESS["AWZ_YDELIVERY_PROFILE_STANDART_SETT_SOURCE"] = "ИД склада отгрузки";
$MESS["AWZ_YDELIVERY_PROFILE_STANDART_SETT_SOURCE_TEST"] = "ИД склада отгрузки тестовый";
$MESS["AWZ_YDELIVERY_PROFILE_STANDART_SETT_DSBL1"] = "Отключить доставку при ошибках расчета";
$MESS["AWZ_YDELIVERY_PROFILE_STANDART_SETT_DSBL2"] = "Отключить доставку при отсутствии сроков доставки";
$MESS["AWZ_YDELIVERY_PROFILE_STANDART_SETT_COST_DEF"] = "Стоимость доставки при ошибке расчета";
$MESS["AWZ_YDELIVERY_PROFILE_STANDART_SETT_WEIGHT_DEF"] = "Вес товара в граммах по умолчанию (если не найден вес товара)";
$MESS["AWZ_YDELIVERY_PROFILE_STANDART_SETT_DEM_DEF"] = "Объем товара в см2 по умолчанию (если не найдены габариты товара)";
$MESS["AWZ_YDELIVERY_PROFILE_STANDART_ERR_REGION"] = "Не указан регион доставки";
$MESS["AWZ_YDELIVERY_PROFILE_STANDART_ERR_COST"] = "Произошла ошибка при расчете стоимости доставки";
$MESS["AWZ_YDELIVERY_PROFILE_STANDART_ERR_NOGRAF"] = "Нет графика доставки";
$MESS["AWZ_YDELIVERY_D"] = "д.";
?>