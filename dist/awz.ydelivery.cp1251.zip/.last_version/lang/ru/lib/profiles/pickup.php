<?
$MESS["AWZ_YDELIVERY_PROFILE_PICKUP_NAME"] = "AWZ: Самовывоз из пунктов выдачи Яндекса";
$MESS["AWZ_YDELIVERY_PROFILE_PICKUP_DESC"] = "Обработчик доставки: Самовывоз из пунктов выдачи Яндекса";
$MESS["AWZ_YDELIVERY_PROFILE_PICKUP_SETT_INTG"] = "Интеграция";
$MESS["AWZ_YDELIVERY_PROFILE_PICKUP_SETT_INTG_DESC"] = "Основные настройки интеграции";
$MESS["AWZ_YDELIVERY_PROFILE_PICKUP_SETT_TEST_MODE"] = "Тестовый режим";
$MESS["AWZ_YDELIVERY_PROFILE_PICKUP_SETT_TOKEN"] = "Ключ API";
$MESS["AWZ_YDELIVERY_PROFILE_PICKUP_SETT_TOKEN_TEST"] = "Ключ API Тестовый";
$MESS["AWZ_YDELIVERY_PROFILE_PICKUP_SETT_SOURCE"] = "ИД склада отгрузки";
$MESS["AWZ_YDELIVERY_PROFILE_PICKUP_SETT_SOURCE_TEST"] = "ИД склада отгрузки тестовый";
$MESS["AWZ_YDELIVERY_PROFILE_PICKUP_SETT_BTN_CLASS"] = "Класс кнопки выбора ПВЗ";
$MESS["AWZ_YDELIVERY_PROFILE_PICKUP_SETT_DSBL1"] = "Отключить доставку при ошибках расчета";
$MESS["AWZ_YDELIVERY_PROFILE_PICKUP_SETT_DSBL2"] = "Отключить доставку при отсутствии сроков доставки";
$MESS["AWZ_YDELIVERY_PROFILE_PICKUP_SETT_COST_DEF"] = "Стоимость доставки при ошибке расчета";
$MESS["AWZ_YDELIVERY_PROFILE_PICKUP_SETT_WEIGHT_DEF"] = "Вес товара в граммах по умолчанию (если не найден вес товара)";
$MESS["AWZ_YDELIVERY_PROFILE_PICKUP_SETT_DEM_DEF"] = "Объем товара в см2 по умолчанию (если не найдены габариты товара)";
$MESS["AWZ_YDELIVERY_PROFILE_PICKUP_ERR_REGION"] = "Не указан регион доставки";
$MESS["AWZ_YDELIVERY_PROFILE_PICKUP_ERR_COST"] = "Произошла ошибка при расчете стоимости доставки";
$MESS["AWZ_YDELIVERY_PROFILE_PICKUP_ERR_NOGRAF"] = "Нет графика доставки";
$MESS["AWZ_YDELIVERY_PROFILE_PICKUP_BTN_OPEN"] = "Выберите пункт выдачи";
$MESS["AWZ_YDELIVERY_D"] = "д.";
?>