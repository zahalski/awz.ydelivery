<?
$MESS["AWZ_YDELIVERY_HELPER_NOT_SALE_MODULE"] = "Модуль sale не установлен";
$MESS["AWZ_YDELIVERY_HELPER_ERR_NO_OFFERS"] = "Нет активных предложений по доставке";
$MESS["AWZ_YDELIVERY_HELPER_ERR_EMPTY_ID"] = "Не передан ид постамата";
$MESS["AWZ_YDELIVERY_HELPER_ERR_EMPTY_DATA"] = "Данные по пункту самовывоза не найдены";
$MESS["AWZ_YDELIVERY_HELPER_PAYNAMES_PREPAY"] = "Заказ и доставка уже оплачены";
$MESS["AWZ_YDELIVERY_HELPER_PAYNAMES_CASH"] = "Оплата заказа и доставки наличными при получении";
$MESS["AWZ_YDELIVERY_HELPER_PAYNAMES_CARD"] = "Оплата заказа и доставки картой при получении";
$MESS["AWZ_YDELIVERY_HELPER_LASTMILE_SELF"] = "Самовывоз";
$MESS["AWZ_YDELIVERY_HELPER_LASTMILE_TI"] = "Интервал";
$MESS["AWZ_YDELIVERY_HELPER_LASTMILE_OD"] = "По требованию";
$MESS["AWZ_YDELIVERY_HELPER_LASTMILE_EX"] = "Срочная";
$MESS["AWZ_YDELIVERY_HELPER_TYPE_PVZ_PICKUP_POINT"] = "ПВЗ";
$MESS["AWZ_YDELIVERY_HELPER_TYPE_PVZ_TERMINAL"] = "постамат";
?>