<?php
$MESS["AWZ_YDELIVERY_HANDLER_NAME"] = "AWZ: Яндекс Доставка";
$MESS["AWZ_YDELIVERY_HANDLER_DESC"] = "Обработчик службы Яндекс Доставка";
$MESS["AWZ_YDELIVERY_HANDLER_NOPROFILE"] = "Доступно только с профиля доставки";