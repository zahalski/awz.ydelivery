<?
$MESS["AWZ_YDELIVERY_OFFERS_TITLE"] = "Список заявок в доставку";
$MESS["AWZ_YDELIVERY_OFFERS_FIELDS_ID"] = "ID";
$MESS["AWZ_YDELIVERY_OFFERS_FIELDS_ORDER_ID"] = "Ид заказа";
$MESS["AWZ_YDELIVERY_OFFERS_FIELDS_OFFER_ID"] = "Ид Яндекс";
$MESS["AWZ_YDELIVERY_OFFERS_FIELDS_LAST_DATE"] = "Дата изменения";
$MESS["AWZ_YDELIVERY_OFFERS_FIELDS_CREATE_DATE"] = "Дата создания";
$MESS["AWZ_YDELIVERY_OFFERS_FIELDS_HISTORY"] = "История изменений";
$MESS["AWZ_YDELIVERY_OFFERS_FIELDS_HISTORY_FIN"] = "Проверка финализирована";
$MESS["AWZ_YDELIVERY_OFFERS_ERR_NO_PVZ"] = "В заказе не указан идентификатор ПВЗ";
$MESS["AWZ_YDELIVERY_OFFERS_ERR_NO_POINT"] = "Не указан идентификатор точки отгрузки";
$MESS["AWZ_YDELIVERY_OFFERS_ERR_NO_PAY"] = "Заказ еще не был оплачен";
$MESS["AWZ_YDELIVERY_OFFERS_ERR_NO_ADDRESS"] = "Не указан адрес доставки";
$MESS["AWZ_YDELIVERY_OFFERS_ERR_NO_REGION"] = "Не указан регион доставки";
$MESS["AWZ_YDELIVERY_OFFERS_ERR_NO_YANDEX"] = "Неверный тип доставки";
$MESS["AWZ_YDELIVERY_OFFERS_ERR_NO_PREP_DATA"] = "Данные для отправки не подготовлены";
$MESS["AWZ_YDELIVERY_OFFERS_ERR_API_NOT_FOUND"] = "Api отключено для данного профиля доставки";
?>