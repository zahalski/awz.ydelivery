<?
$MESS["AWZ_YDELIVERY_HANDLERBX_CHOISE"] = "Выбрать";
$MESS["AWZ_YDELIVERY_HANDLERBX_CHOISE_PVZ"] = "Выбрать пвз";
$MESS["AWZ_YDELIVERY_HANDLERBX_ERR_PAY1"] = "Выбранный способ оплаты не доступен в данном пункте выдачи заказов";
$MESS["AWZ_YDELIVERY_HANDLERBX_ERR_PVZDATA"] = "Не найдена информация по пункту выдачи заказа";
$MESS["AWZ_YDELIVERY_HANDLERBX_ERR_PVZ"] = "Не выбран пункт выдачи заказа";
$MESS["AWZ_YDELIVERY_HANDLERBX_ERR_PVZ_PROP"] = "Не указано свойство для записи идентификатора ПВЗ";
$MESS["AWZ_YDELIVERY_HANDLERBX_BTN_OPEN_OLD"] = "Посмотреть заявку в доставку";
$MESS["AWZ_YDELIVERY_HANDLERBX_BTN_OPEN_NEW"] = "Новая заявка в доставку";
$MESS["AWZ_YDELIVERY_HANDLERBX_HANDLER_NAME"] = "Яндекс Доставка";
?>