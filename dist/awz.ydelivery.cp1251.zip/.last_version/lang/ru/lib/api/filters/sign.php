<?php
$MESS["AWZ_YDELIVERY_API_FILTERS_ERR_SIGN"] = "Ошибка проверки подписи";