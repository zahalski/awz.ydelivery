<?php
$MESS["AWZ_YDELIVERY_API_CONTROL_PICKPOINTS_ERR_REQ"] = "ошибка в параметрах запроса";
$MESS["AWZ_YDELIVERY_API_CONTROL_PICKPOINTS_ERR_PROP"] = "свойство не найдено";
$MESS["AWZ_YDELIVERY_API_CONTROL_PICKPOINTS_OK_ADDR"] = "Значение #POINT# записано в свойство с кодом #PROP#";
$MESS["AWZ_YDELIVERY_API_CONTROL_PICKPOINTS_OK_ADDR_ADD"] = "адрес ПВЗ обновлен в свойстве с кодом #PROP#";
$MESS["AWZ_YDELIVERY_API_CONTROL_PICKPOINTS_ID_ERR"] = "Идентификатор точки обязателен";
$MESS["AWZ_YDELIVERY_API_CONTROL_PICKPOINTS_PROFILE_ERR"] = "Идентификатор доставки не найден";
$MESS["AWZ_YDELIVERY_API_CONTROL_PICKPOINTS_SESS_ERR"] = "Ошибка проверки сессии";
$MESS["AWZ_YDELIVERY_API_CONTROL_PICKPOINTS_ADDRGEO_ERR"] = "Адрес или geo_id обязателен";
$MESS["AWZ_YDELIVERY_API_CONTROL_PICKPOINTS_PVZ_ERR"] = "Пункты выдачи не загружены";
$MESS["AWZ_YDELIVERY_API_CONTROL_PICKPOINTS_ERR_POINT_DATA"] = "Данные по пункту выдачи не найдены в базе";