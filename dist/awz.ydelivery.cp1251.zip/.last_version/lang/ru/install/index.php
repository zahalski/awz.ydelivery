<?
$MESS["AWZ_YDELIVERY_MODULE_NAME"] = "AWZ: Яндекс Доставка";
$MESS["AWZ_YDELIVERY_MODULE_DESCRIPTION"] = "Модуль Интеграции с логистической платформой Яндекс Доставка";
$MESS["AWZ_PARTNER_NAME"] = "Andrew Zahalski";
$MESS["AWZ_PARTNER_URI"] = "https://zahalski.dev";
$MESS["AWZ_YDELIVERY_INSTALL_TITLE"] = "Удаление модуля AWZ: Яндекс Доставка";
?>