<?php
$MESS["AWZ_YDELIVERY_MENU_NAME"] = "AWZ: Яндекс Доставка";
$MESS["AWZ_YDELIVERY_MENU_LIST"] = "Список заявок";