<?php
$MESS["AWZ_YDELIVERY_ADMIN_OL_EMPTY_STATUS"] = "ожидается получение статуса";
$MESS["AWZ_YDELIVERY_ADMIN_OL_TITLE"] = "Список заявок в доставку";
$MESS["AWZ_YDELIVERY_ADMIN_OL_ORDER_FIELD_STATUS"] = "Статус заказа";
$MESS["AWZ_YDELIVERY_ADMIN_OL_DELETE_OFFER"] = "Отменить заявку";
$MESS["AWZ_YDELIVERY_ADMIN_OL_DELETE_OFFER_CONFIRM"] = "Действительно хотите Отменить заявку?";
$MESS["AWZ_YDELIVERY_ADMIN_OL_Y"] = "Да";
$MESS["AWZ_YDELIVERY_ADMIN_OL_N"] = "Нет";