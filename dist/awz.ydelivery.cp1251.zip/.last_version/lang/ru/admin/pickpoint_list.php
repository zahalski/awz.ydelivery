<?
$MESS["AWZ_YDELIVERY_ADMIN_PL_TITLE"] = "Заявка в доставку";
$MESS["AWZ_YDELIVERY_ADMIN_PL_ERR_REGION"] = "В заказе не указан регион доставки";
$MESS["AWZ_YDELIVERY_ADMIN_PL_PAY1"] = "наличные";
$MESS["AWZ_YDELIVERY_ADMIN_PL_PAY2"] = "карта";
$MESS["AWZ_YDELIVERY_ADMIN_PL_PAY3"] = "предоплата";
$MESS["AWZ_YDELIVERY_ADMIN_PL_PAY4"] = "ПВЗ";
$MESS["AWZ_YDELIVERY_ADMIN_PL_PAY5"] = "постамат";
$MESS["AWZ_YDELIVERY_ADMIN_PL_COPY"] = "Скопируйте значение в свойство заказа";
$MESS["AWZ_YDELIVERY_ADMIN_PL_ORDER_SEND"] = "Отправить в заказ ID";
$MESS["AWZ_YDELIVERY_ADMIN_PL_ERR_DOST_TYPE"] = "Яндекс Доставка не найдена в заказе";
$MESS["AWZ_YDELIVERY_ID_POSTAMATA"] = "Ид постамата ";
?>