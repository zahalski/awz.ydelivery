<?
$arModuleVersion = [
    "VERSION" => "1.1.3",
    "VERSION_DATE" => "2024-06-19 14:42:00"
];