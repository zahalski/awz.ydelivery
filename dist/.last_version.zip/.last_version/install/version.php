<?
$arModuleVersion = array(
    "VERSION" => "1.0.13",
    "VERSION_DATE" => "2022-07-03 0:27:00"
);