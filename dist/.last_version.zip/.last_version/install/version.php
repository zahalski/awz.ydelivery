<?
$arModuleVersion = array(
    "VERSION" => "1.0.27",
    "VERSION_DATE" => "2022-12-18 22:22:00"
);