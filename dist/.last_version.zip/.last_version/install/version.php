<?
$arModuleVersion = [
    "VERSION" => "1.1.6",
    "VERSION_DATE" => "2024-10-10 10:19:00"
];