<?
$arModuleVersion = [
    "VERSION" => "1.0.45",
    "VERSION_DATE" => "2023-07-18 13:55:00"
];