<?
$arModuleVersion = array(
    "VERSION" => "1.0.16",
    "VERSION_DATE" => "2022-07-11 10:53:00"
);