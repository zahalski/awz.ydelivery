<?
$arModuleVersion = array(
    "VERSION" => "1.0.31",
    "VERSION_DATE" => "2022-12-21 23:10:00"
);