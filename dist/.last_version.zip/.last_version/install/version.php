<?
$arModuleVersion = [
    "VERSION" => "1.0.42",
    "VERSION_DATE" => "2023-05-28 12:46:00"
];