<?
$arModuleVersion = [
    "VERSION" => "1.0.41",
    "VERSION_DATE" => "2023-03-28 12:46:00"
];