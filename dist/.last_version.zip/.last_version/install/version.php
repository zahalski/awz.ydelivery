<?
$arModuleVersion = [
    "VERSION" => "1.1.5",
    "VERSION_DATE" => "2024-09-15 09:11:00"
];