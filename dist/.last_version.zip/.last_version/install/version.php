<?
$arModuleVersion = array(
    "VERSION" => "1.0.34",
    "VERSION_DATE" => "2022-12-23 19:37:00"
);