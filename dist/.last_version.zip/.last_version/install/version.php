<?
$arModuleVersion = array(
    "VERSION" => "1.0.11",
    "VERSION_DATE" => "2022-07-02 13:29:00"
);