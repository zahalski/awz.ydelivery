<?
$arModuleVersion = [
    "VERSION" => "1.0.48",
    "VERSION_DATE" => "2024-04-30 07:03:00"
];