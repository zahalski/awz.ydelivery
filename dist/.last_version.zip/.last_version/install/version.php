<?
$arModuleVersion = array(
    "VERSION" => "1.0.6",
    "VERSION_DATE" => "2022-06-29 0:58:00"
);