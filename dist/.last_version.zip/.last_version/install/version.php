<?
$arModuleVersion = [
    "VERSION" => "1.0.46",
    "VERSION_DATE" => "2023-07-18 14:00:00"
];