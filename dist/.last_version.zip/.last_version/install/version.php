<?
$arModuleVersion = array(
    "VERSION" => "1.0.23",
    "VERSION_DATE" => "2022-12-14 01:46:00"
);