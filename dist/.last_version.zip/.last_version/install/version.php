<?
$arModuleVersion = array(
    "VERSION" => "1.0.7",
    "VERSION_DATE" => "2022-06-29 12:39:00"
);