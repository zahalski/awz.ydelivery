<?
$arModuleVersion = array(
    "VERSION" => "1.0.24",
    "VERSION_DATE" => "2022-12-14 02:11:00"
);