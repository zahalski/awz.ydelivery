<?
$arModuleVersion = array(
    "VERSION" => "1.0.28",
    "VERSION_DATE" => "2022-12-20 17:17:00"
);