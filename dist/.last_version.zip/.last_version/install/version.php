<?
$arModuleVersion = array(
    "VERSION" => "1.0.18",
    "VERSION_DATE" => "2022-07-24 16:33:00"
);