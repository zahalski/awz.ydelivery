<?
$arModuleVersion = [
    "VERSION" => "1.1.7",
    "VERSION_DATE" => "2024-10-22 08:14:00"
];