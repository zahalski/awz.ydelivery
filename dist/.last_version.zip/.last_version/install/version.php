<?
$arModuleVersion = [
    "VERSION" => "1.0.47",
    "VERSION_DATE" => "2023-08-03 18:50:00"
];