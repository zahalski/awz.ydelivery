<?
$arModuleVersion = array(
    "VERSION" => "1.0.22",
    "VERSION_DATE" => "2022-12-12 21:21:00"
);