<?
$arModuleVersion = [
    "VERSION" => "1.0.36",
    "VERSION_DATE" => "2023-01-10 20:06:00"
];