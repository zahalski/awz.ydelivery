<?
$arModuleVersion = [
    "VERSION" => "1.0.40",
    "VERSION_DATE" => "2023-03-23 16:15:00"
];