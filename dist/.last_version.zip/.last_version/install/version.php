<?
$arModuleVersion = array(
    "VERSION" => "1.0.12",
    "VERSION_DATE" => "2022-07-02 15:11:00"
);