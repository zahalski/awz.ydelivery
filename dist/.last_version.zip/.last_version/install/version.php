<?
$arModuleVersion = array(
    "VERSION" => "1.0.21",
    "VERSION_DATE" => "2022-12-11 18:07:00"
);