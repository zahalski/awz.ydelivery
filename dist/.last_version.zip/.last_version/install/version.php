<?
$arModuleVersion = array(
    "VERSION" => "1.0.14",
    "VERSION_DATE" => "2022-07-09 18:55:00"
);