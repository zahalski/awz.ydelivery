<?
$arModuleVersion = array(
    "VERSION" => "1.0.3",
    "VERSION_DATE" => "2022-06-27 23:50:00"
);