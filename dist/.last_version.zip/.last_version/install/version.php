<?
$arModuleVersion = array(
    "VERSION" => "1.0.25",
    "VERSION_DATE" => "2022-12-15 23:39:00"
);