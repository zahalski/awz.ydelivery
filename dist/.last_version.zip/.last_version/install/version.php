<?
$arModuleVersion = [
    "VERSION" => "1.1.0",
    "VERSION_DATE" => "2024-06-02 07:03:00"
];