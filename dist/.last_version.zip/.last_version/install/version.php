<?
$arModuleVersion = array(
    "VERSION" => "1.0.4",
    "VERSION_DATE" => "2022-06-28 10:17:00"
);