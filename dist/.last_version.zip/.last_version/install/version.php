<?
$arModuleVersion = [
    "VERSION" => "1.1.4",
    "VERSION_DATE" => "2024-06-19 21:49:00"
];