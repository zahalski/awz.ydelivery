<?
$arModuleVersion = [
    "VERSION" => "1.0.38",
    "VERSION_DATE" => "2023-03-20 00:21:00"
];