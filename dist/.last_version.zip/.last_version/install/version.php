<?
$arModuleVersion = [
    "VERSION" => "1.0.44",
    "VERSION_DATE" => "2023-07-06 15:39:00"
];