<?
$arModuleVersion = array(
    "VERSION" => "1.0.19",
    "VERSION_DATE" => "2022-11-17 19:47:00"
);