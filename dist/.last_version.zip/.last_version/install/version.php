<?
$arModuleVersion = [
    "VERSION" => "1.0.39",
    "VERSION_DATE" => "2023-03-20 19:10:00"
];