<?
$arModuleVersion = [
    "VERSION" => "1.0.43",
    "VERSION_DATE" => "2023-07-02 10:04:00"
];