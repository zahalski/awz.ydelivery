<?
$arModuleVersion = [
    "VERSION" => "1.1.1",
    "VERSION_DATE" => "2024-06-03 18:15:00"
];