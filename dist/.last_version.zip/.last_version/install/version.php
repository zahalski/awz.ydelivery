<?
$arModuleVersion = [
    "VERSION" => "1.1.8",
    "VERSION_DATE" => "2025-01-13 17:54:00"
];