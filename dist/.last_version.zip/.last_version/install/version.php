<?
$arModuleVersion = array(
    "VERSION" => "1.0.8",
    "VERSION_DATE" => "2022-06-29 13:35:00"
);