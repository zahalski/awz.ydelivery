<?
$arModuleVersion = array(
    "VERSION" => "1.0.2",
    "VERSION_DATE" => "2022-06-26 02:14:00"
);