<?
$arModuleVersion = [
    "VERSION" => "1.0.37",
    "VERSION_DATE" => "2023-01-13 22:25:00"
];