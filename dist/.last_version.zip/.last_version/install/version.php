<?
$arModuleVersion = array(
    "VERSION" => "1.0.32",
    "VERSION_DATE" => "2022-12-22 00:37:00"
);