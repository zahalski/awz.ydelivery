drop table if exists b_awz_ydelivery_offer;
drop table if exists b_awz_ydelivery_pvz;
drop table if exists b_awz_ydelivery_pvz_ext;