<?php
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/awz.ydelivery/admin/pickpoint_list.php");