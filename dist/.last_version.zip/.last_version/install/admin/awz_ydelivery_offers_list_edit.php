<?
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/awz.ydelivery/admin/offers_list_edit.php");
