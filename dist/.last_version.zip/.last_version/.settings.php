<?php
return [
    'controllers' => [
        'value' => [
            'namespaces' => [
                '\\Awz\\Ydelivery\\Api\\Controller' => 'api'
            ]
        ],
        'readonly' => true
    ]
];