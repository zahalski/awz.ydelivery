<?php
return array(
    'controllers' => array(
        'value' => array(
            'namespaces' => array(
                '\\Awz\\Ydelivery\\Api\\Controller' => 'api'
            )
        ),
        'readonly' => true
    )
);